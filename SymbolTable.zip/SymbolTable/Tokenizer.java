import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Tokenizer {

    // LinkedList to store tokens
    static LinkedList<String> tokens = new LinkedList<>();
    static LinkedList<Identifier> identifiers = new LinkedList<>();  // Store identifiers

    // Hash Table implementation to store nodes
    static final int TABLE_SIZE = 100;
    static Node[] head = new Node[TABLE_SIZE];

    // Java reserved keywords
    static Set<String> javaKeywords = new HashSet<>(Arrays.asList(
        "public", "private", "protected", "static", "void", "int", "float", "char", "double", "long", "boolean",
        "if", "else", "while", "for", "switch", "case", "break", "continue", "return", "try", "catch", "finally",
        "throw", "throws", "new", "import", "package", "class", "interface", "extends", "implements", "enum", "this"
    ));

    // Node class for the hash table
    static class Node {
        String identifier;
        String scope;
        Node next;

        // Constructor to initialize Node
        public Node(String identifier, String scope) {
            this.identifier = identifier;
            this.scope = scope;
            this.next = null;
        }
    }

    // Class to store identifier information (name, type, and data type)
    static class Identifier {
        String name;
        String dataType;  // int, void, etc.
        String identifierType;  // Function or Variable

        // Constructor to initialize Identifier
        public Identifier(String name, String dataType, String identifierType) {
            this.name = name;
            this.dataType = dataType;
            this.identifierType = identifierType;
        }
    }

    // Hash function to map an identifier to a table index
    public static int hashf(String id) {
        return Math.abs(id.hashCode()) % TABLE_SIZE;  // Use absolute value to avoid negative indices
    }

    // Function to insert a new identifier into the hash table
    public static boolean insert(String id, String scope) {
        Node p = new Node(id, scope);  // Create a new node
        int index = hashf(id);  // Get index using hash function

        // If the index is empty (null), insert the new node directly
        if (head[index] == null) {
            head[index] = p;
            return true;
        } else {
            // Traverse the linked list to insert the node at the end
            Node start = head[index];
            while (start.next != null) {
                start = start.next;
            }
            start.next = p;
            return true;
        }
    }

    // Function to find an identifier in the hash table
    public static String find(String id) {
        int index = hashf(id);  // Get index using hash function
        Node start = head[index];

        // If the index is empty (null), return "-1"
        if (start == null) {
            return "-1";
        }

        // Traverse the linked list to find the identifier
        while (start != null) {
            if (start.identifier.equals(id)) {
                // Identifier found, return its scope
                return start.scope;
            }
            start = start.next;
        }
        // Return "-1" if the identifier was not found
        return "-1";
    }

    // Function to delete an identifier from the hash table
    public static boolean delete(String id) {
        int index = hashf(id);
        Node current = head[index];
        Node prev = null;

        while (current != null) {
            if (current.identifier.equals(id)) {
                if (prev == null) {
                    head[index] = current.next;
                } else {
                    prev.next = current.next;
                }
                return true;
            }
            prev = current;
            current = current.next;
        }
        return false;
    }

    // Function to tokenize the source code from a file
    public static void tokenizeFile(String filePath) throws IOException {
        File file = new File(filePath);
        FileReader read = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(read);

        int ch;
        StringBuilder token = new StringBuilder();
        while ((ch = bufferedReader.read()) != -1) {
            char c = (char) ch;

            // If the character is a whitespace, process the token
            if (Character.isWhitespace(c)) {
                if (token.length() > 0) {
                    String tokenStr = token.toString();
                    if (isIdentifier(tokenStr) && !javaKeywords.contains(tokenStr)) {
                        tokens.add(tokenStr);
                        identifiers.add(new Identifier(tokenStr, "", ""));  // Store identifier
                        // Insert into hash table with default "global" scope.
                        insert(tokenStr, "global");
                    }
                    token.setLength(0);  // Reset the token
                }
            } else {
                // Otherwise, concatenate the character to the current token
                token.append(c);
            }
        }
        // Add the last token if any exists
        if (token.length() > 0) {
            String tokenStr = token.toString();
            if (isIdentifier(tokenStr) && !javaKeywords.contains(tokenStr)) {
                tokens.add(tokenStr);
                identifiers.add(new Identifier(tokenStr, "", ""));  // Store identifier
                insert(tokenStr, "global");
            }
        }

        read.close();
    }

    // Check if the token is an identifier
    private static boolean isIdentifier(String token) {
        // Define what you consider an identifier (e.g., no spaces or special characters)
        return token.matches("[a-zA-Z_][a-zA-Z0-9_]*");
    }

    // Function to categorize each identifier (Variable or Function)
    public static void categorizeIdentifiers(String filePath) throws IOException {
        // Read entire file content into a single string
        String content = new String(Files.readAllBytes(Paths.get(filePath)));
       
        // Regex to detect function declarations.
        // This pattern looks for an optional modifier sequence followed by a data type and an identifier that is immediately followed by '('
        Pattern functionPattern = Pattern.compile("\\b(?:public|private|protected|static|final|abstract\\s+)*\\s*(\\w+)\\s+(\\w+)\\s*\\(");
        Matcher functionMatcher = functionPattern.matcher(content);
        while(functionMatcher.find()){
            String dataType = functionMatcher.group(1);
            String name = functionMatcher.group(2);
            for(Identifier identifier: identifiers){
                if(identifier.name.equals(name)){
                    identifier.identifierType = "Function";
                    identifier.dataType = dataType;
                }
            }
        }
       
        // Regex to detect variable declarations.
        // This pattern will look for int, float, or String followed by a space and an identifier.
        Pattern variablePattern = Pattern.compile("\\b(int|float|String)\\s+(\\w+)");
        Matcher variableMatcher = variablePattern.matcher(content);
        while(variableMatcher.find()){
            String dataType = variableMatcher.group(1);
            String name = variableMatcher.group(2);
            for(Identifier identifier: identifiers){
                // Do not overwrite if already set as a function.
                if(identifier.name.equals(name) && !"Function".equals(identifier.identifierType)){
                    identifier.identifierType = "Variable";
                    identifier.dataType = dataType;
                }
            }
        }
    }

    // Function to display all identifiers with their type and data type
    public static void displayIdentifiers() {
        if (identifiers.isEmpty()) {
            System.out.println("No identifiers to display.");
        } else {
            System.out.println("Stored Identifiers:");
            for (Identifier identifier : identifiers) {
                System.out.println("Name: " + identifier.name + ", Data Type: " + identifier.dataType + ", Type: " + identifier.identifierType);
            }
        }
    }
    
    // Lookup function: prompts for an identifier and displays its scope using the hash table lookup
    public static void lookupIdentifier(Scanner scanner) {
        System.out.print("Enter the identifier to lookup: ");
        String id = scanner.nextLine();
        String scope = find(id);
        if (scope.equals("-1")) {
            System.out.println("Identifier \"" + id + "\" not found.");
        } else {
            System.out.println("Identifier \"" + id + "\" found with scope: " + scope);
        }
    }
    
    // Delete function: prompts for an identifier, deletes it from the hash table and from the lists, and displays the result.
    public static void deleteIdentifier(Scanner scanner) {
        System.out.print("Enter the identifier to delete: ");
        String id = scanner.nextLine();
        boolean success = delete(id);
        if (success) {
            // Also remove from tokens and identifiers lists
            tokens.removeIf(token -> token.equals(id));
            identifiers.removeIf(identifier -> identifier.name.equals(id));
            System.out.println("Identifier \"" + id + "\" deleted successfully.");
        } else {
            System.out.println("Identifier \"" + id + "\" not found.");
        }
    }

    // Function to display the menu and process user input
    public static void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;  // Initialize the choice variable

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Tokenize and Insert");
            System.out.println("2. Display Identifiers");
            System.out.println("3. Categorize Identifiers");
            System.out.println("4. Lookup Identifier");
            System.out.println("5. Delete Identifier");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline left over by nextInt()

                switch (choice) {
                    case 1:
                        System.out.print("Enter the file path for tokenization: ");
                        String filePath = scanner.nextLine();
                        try {
                            tokenizeFile(filePath);
                        } catch (IOException e) {
                            System.out.println("Error reading the file: " + e.getMessage());
                        }
                        break;

                    case 2:
                        displayIdentifiers();
                        break;

                    case 3:
                        System.out.print("Enter the file path for categorization: ");
                        String categorizeFilePath = scanner.nextLine();
                        try {
                            categorizeIdentifiers(categorizeFilePath);
                        } catch (IOException e) {
                            System.out.println("Error reading the file: " + e.getMessage());
                        }
                        break;
                        
                    case 4:
                        lookupIdentifier(scanner);
                        break;
                        
                    case 5:
                        deleteIdentifier(scanner);
                        break;

                    case 6:
                        System.out.println("Exiting the program.");
                        break;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // consume invalid input
            }
        } while (choice != 6);

        scanner.close();
    }

    public static void main(String[] args) {
        // Display the menu and handle user choices
        displayMenu();
    }
}
