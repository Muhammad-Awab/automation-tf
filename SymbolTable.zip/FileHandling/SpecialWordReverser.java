	public class SpecialWordReverser {
	
	    public static void main(String[] args) {
	        String input = "hello w@rld code#java";
	        System.out.println("210943 Muhammad Awab");
	        System.out.println(transformSpecialWords(input));
	    }
	
	    public static String transformSpecialWords(String input) {
	        String[] words = input.split(" ");
	        StringBuilder result = new StringBuilder();
	
	        for (String word : words) {
	            if (containsSpecialChar(word)) {
	                result.append(reverseWordKeepingSpecial(word)).append(" ");
	            } else {
	                result.append(word).append(" ");
	            }
	        }
	
	        return result.toString().trim();
	    }
	
	    private static boolean containsSpecialChar(String word) {
	        for (char c : word.toCharArray()) {
	            if ("@#$%&".contains(Character.toString(c))) {
	                return true;
	            }
	        }
	        return false;
	    }
	
	    private static String reverseWordKeepingSpecial(String word) {
	        char[] letters = word.toCharArray();
	        int left = 0, right = letters.length - 1;
	
	        while (left < right) {
	            if (isSpecialChar(letters[left])) {
	                left++;
	            } else if (isSpecialChar(letters[right])) {
	                right--;
	            } else {
	                char temp = letters[left];
	                letters[left] = letters[right];
	                letters[right] = temp;
	                left++;
	                right--;
	            }
	        }
	
	        return new String(letters);
	    }
	
	    private static boolean isSpecialChar(char c) {
	        return "@#$%&".indexOf(c) != -1;
	    }
	}
