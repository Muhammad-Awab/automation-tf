public class VowelTransformer{

    public static void main(String[] args) {
        String input = "hello world";
        System.out.println("210943 Muhammad Awab");
        System.out.println(transformVowels(input));
    }

    public static String transformVowels(String input) {
        StringBuilder result = new StringBuilder();

        for (char c : input.toCharArray()) {
            if (isVowel(c)) {
                result.append(Character.toUpperCase(c));
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }

    private static boolean isVowel(char c) {
        char lowerC = Character.toLowerCase(c);
        return lowerC == 'a' || lowerC == 'e' || lowerC == 'i' || lowerC == 'o' || lowerC == 'u';
    }
}
