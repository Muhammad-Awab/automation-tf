import java.io.*;
import java.util.*;

class Product {
    int productId;
    String productName;
    int quantity;
    double price;

    public Product(int productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product ID: " + productId + ", Name: " + productName +
               ", Quantity: " + quantity + ", Price: " + price;
    }

    // Returns the product data in CSV format for file writing.
    public String toCSV() {
        return productId + ", " + productName + ", " + quantity + ", " + price;
    }
}

public class InventoryManager {

    private static final String FILE_NAME = "inventory.txt";
    private static List<Product> products = new ArrayList<>();

    public static void main(String[] args) {
        // Load inventory from file at startup
        loadInventory();

        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        while (true) {
            System.out.println("\n--- Inventory Management System ---");
            System.out.println("1. View Inventory");
            System.out.println("2. Add Product");
            System.out.println("3. Update Product Quantity");
            System.out.println("4. Calculate Total Inventory Value");
            System.out.println("5. Exit");
            System.out.print("\nEnter your choice: ");
            
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number from 1 to 5.");
                continue;
            }
            
            switch (choice) {
                case 1:
                    viewInventory();
                    break;
                case 2:
                    addProduct(scanner);
                    break;
                case 3:
                    updateProduct(scanner);
                    break;
                case 4:
                    calculateTotalValue();
                    break;
                case 5:
                    // Save the inventory to file before exiting
                    saveInventory();
                    System.out.println("Exiting program. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please choose from 1 to 5.");
            }
        }
    }

    // Loads the inventory from the file into the products list.
    private static void loadInventory() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            // If the file does not exist, create an empty file.
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Error creating inventory file: " + e.getMessage());
                return;
            }
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            products.clear();
            while ((line = br.readLine()) != null) {
                // Assuming each line is in format: id, name, quantity, price
                String[] parts = line.split(",");
                if (parts.length != 4) continue; // skip invalid lines
                try {
                    int id = Integer.parseInt(parts[0].trim());
                    String name = parts[1].trim();
                    int quantity = Integer.parseInt(parts[2].trim());
                    double price = Double.parseDouble(parts[3].trim());
                    products.add(new Product(id, name, quantity, price));
                } catch (NumberFormatException e) {
                    System.out.println("Skipping invalid line: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading inventory file: " + e.getMessage());
        }
    }

    // Writes the current inventory back to the file.
    private static void saveInventory() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Product p : products) {
                bw.write(p.toCSV());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing to inventory file: " + e.getMessage());
        }
    }

    // Displays all products in the inventory.
    private static void viewInventory() {
        System.out.println("\n--- Inventory List ---");
        if (products.isEmpty()) {
            System.out.println("Inventory is empty.");
        } else {
            for (Product p : products) {
                System.out.println(p);
            }
        }
    }

    // Adds a new product to the inventory.
    private static void addProduct(Scanner scanner) {
        try {
            System.out.print("Enter Product ID: ");
            int id = Integer.parseInt(scanner.nextLine());
            
            // Check if the product already exists
            for (Product p : products) {
                if (p.productId == id) {
                    System.out.println("Product with ID " + id + " already exists.");
                    return;
                }
            }
            
            System.out.print("Enter Product Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Quantity: ");
            int quantity = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Price: ");
            double price = Double.parseDouble(scanner.nextLine());
            
            products.add(new Product(id, name, quantity, price));
            // Update file immediately after adding
            saveInventory();
            System.out.println("Product added successfully.");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numeric values for ID, Quantity, and Price.");
        }
    }

    // Updates the quantity of an existing product.
    private static void updateProduct(Scanner scanner) {
        try {
            System.out.print("Enter Product ID to update: ");
            int id = Integer.parseInt(scanner.nextLine());
            boolean found = false;
            for (Product p : products) {
                if (p.productId == id) {
                    System.out.print("Enter new quantity: ");
                    int newQuantity = Integer.parseInt(scanner.nextLine());
                    p.quantity = newQuantity;
                    found = true;
                    break;
                }
            }
            if (found) {
                saveInventory();
                System.out.println("Product quantity updated successfully.");
            } else {
                System.out.println("Product with ID " + id + " not found.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numeric values for ID and Quantity.");
        }
    }

    // Calculates and displays the total inventory value.
    private static void calculateTotalValue() {
        double totalValue = 0;
        for (Product p : products) {
            totalValue += p.quantity * p.price;
        }
        System.out.println("Total Inventory Value: " + totalValue);
    }
}
