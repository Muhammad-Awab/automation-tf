public class Task3 {
    public static void main(String[] args) {
        int q0 = 0; // initial state
        int q1 = 1; // Digits
        int q2 = 2; // Identifiers
        int q3 = 3; // Operators
        int q4 = 4; // Curly brace state
        int q5 = 5; // Assignment operator
        int q6 = 6; // Special character state
        int[] acceptingStates = { q1, q2, q3, q4, q5, q6 };
        int state = q0; // current state
        String[] testStrings = {
                "123", // digits
                "var_name", // identifier
                "+", // operator
                "{", // curly brace
                "=", // assignment operator
                ";", // special character
                "1a", // invalid
                ";a", // invalid
        };
        for (String inputString : testStrings) {
            state = q0;
            boolean isValid = true;
            for (char symbol : inputString.toCharArray()) {
                if (state == q0) {
                    if (Character.isDigit(symbol)) {
                        state = q1;
                    } else if (Character.isAlphabetic(symbol) || symbol == '_') {
                        state = q2;
                    } else if ("+-*/%&|^=!<>".indexOf(symbol) != -1) {
                        state = q3;
                    } else if ("{}".indexOf(symbol) != -1) {
                        state = q4;
                    } else if (";,.()[]".indexOf(symbol) != -1) {
                        state = q6;
                    } else if (symbol == '=') {
                        state = q5;
                    } else {
                        state = -1;
                        isValid = false;
                        break;
                    }

                } else if (state == q1) {
                    if (Character.isDigit(symbol)) {
                        state = q1;
                    } else {
                        state = -1;
                        isValid = false;
                        break;
                    }
                } else if (state == q2) {
                    if (Character.isAlphabetic(symbol) || Character.isDigit(symbol)
                            || symbol == '_') {
                        state = q2;
                    } else {
                        state = -1;
                        isValid = false;
                        break;
                    }
                } else if (state == q3 || state == q4 || state == q5 || state == q6) {
                    state = q0;
                }
            }
            boolean isAccepted = false;
            for (int acceptingState : acceptingStates) {
                if (state == acceptingState) {
                    isAccepted = true;
                    break;
                }
            }
            System.out.println("'" + inputString + "' -> " + (isValid && isAccepted ? "Accepted" : "Rejected"));
        }
    }
}