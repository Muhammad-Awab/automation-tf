import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter string 00: ");
        String input = scanner.next();
        scanner.close();

        if (isAccepted(input)) {
            System.out.println("Accepted: The string starts and ends with '00'.");
        } else {
            System.out.println("Rejected: The string does not start and end with '00'.");
        }
    }

    public static boolean isAccepted(String str) {
        if (str.length() < 2) return false; 

        return str.startsWith("00") && str.endsWith("00");
    }
}
