import java.util.*;

public class DFA_Tokenizer {
    
    // Define possible token types
    enum TokenType {
        IDENTIFIER, DIGIT, OPERATOR, BRACE, ASSIGNMENT, SPECIAL, UNKNOWN
    }

    // DFA function to classify tokens
    public static TokenType getTokenType(String token) {
        if (token.matches("[0-9]+")) return TokenType.DIGIT; // Digit (0-9)
        if (token.matches("[a-zA-Z_][a-zA-Z0-9_]*")) return TokenType.IDENTIFIER; // Identifiers
        if (token.matches("[+\\-*/%]")) return TokenType.OPERATOR; // Operators (+,-,*,/,%)
        if (token.matches("[{}]")) return TokenType.BRACE; // Curly Braces ({,})
        if (token.equals("=")) return TokenType.ASSIGNMENT; // Assignment Operator (=)
        if (token.matches("[;(),.]")) return TokenType.SPECIAL; // Special Characters (; , ( ) .)
        return TokenType.UNKNOWN; // Anything else
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter a string to tokenize: ");
        String input = scanner.nextLine();
        
        // Splitting input into tokens using regex (spaces and common delimiters)
        String[] tokens = input.split("\\s+");
        
        System.out.println("\nToken Classification:");
        for (String token : tokens) {
            TokenType type = getTokenType(token);
            System.out.println(token + " --> " + type);
        }

        scanner.close();
    }
}
