import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter string 101:  ");
        String input = scanner.next();
        scanner.close();

        if (isAccepted(input)) {
            System.out.println("Accepted: The string contains '101' as a substring.");
        } else {
            System.out.println("Rejected: The string does not contain '101' as a substring.");
        }
    }

    public static boolean isAccepted(String str) {
        int state = 0;  // Start state
        for (char c : str.toCharArray()) {
            if (c == '1') {
                if (state == 0) state = 1;  
                else if (state == 2) state = 3; 
            } else if (c == '0') {
                if (state == 1) state = 2;  
            } else {
                return false; 
            }
        }
        return state == 3; 
    }
}
