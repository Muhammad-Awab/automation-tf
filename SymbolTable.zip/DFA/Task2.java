import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Task2 {
    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new

        InputStreamReader(System.in));
        int i, ip, ns;
        int l = 0;
        System.out.println("Enter the length of string: ");
        try {
            l = Integer.parseInt(br.readLine());

        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Enter the string 0/1: ");
        int a[] = new int[l];
        for (i = 0; i < l; i++) {
            try {
                a[i] = Integer.parseInt(br.readLine());
            } catch (NumberFormatException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        int q[][] = { { 1, 5 }, { 2, 5 }, { 2, 3 }, { 4, 3 }, { 2, 3 }, { 5, 5 } };
        int in = 0, fs = 2, cs = in;
        System.out.print("q" + cs);
        for (i = 0; i < l; i++) {
            ip = a[i];
            ns = q[cs][ip];
            cs = ns;
            System.out.print("-->q" + cs);
        }
        System.out.println("\nCurrent State is = " + cs);
        System.out.println("Final State is = " + fs);
        if (cs == fs)
            System.out.println("String is Accepted");
        else
            System.out.println("String is Rejected");
    }

}