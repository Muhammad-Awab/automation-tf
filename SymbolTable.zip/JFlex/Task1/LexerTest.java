import java.io.*;

public class LexerTest {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter input: ");
        String input = br.readLine();

        Lexer lexer = new Lexer(new StringReader(input));

        while (true) {
            String token = lexer.yylex();
            if (token == null) break;
            System.out.println(token);
        }
    }
}
