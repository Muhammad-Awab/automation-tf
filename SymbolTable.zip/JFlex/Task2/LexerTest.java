import java.io.*;

public class LexerTest {
    public static void main(String[] args) {
        try {
            // Read input file
            FileReader reader = new FileReader("testCode.txt");
            Lexer lexer = new Lexer(reader);

            // Process tokens
            String token;
            while ((token = lexer.yylex()) != null) {
                System.out.println(token);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: Source file not found.");
        } catch (IOException e) {
            System.out.println("Error reading the file.");
        }
    }
}
