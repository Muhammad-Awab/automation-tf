import java.util.Stack;

public class LL1_Parser {
    public String input = "";
    private int indexOfInput = -1;
    Stack<String> strack = new Stack<String>();

    String[][] table = {
        {"(S+F)", null, "F", null, null}, // S
        {null, null, "a", null, null}     // F
    };

    String[] nonTers = {"S", "F"};
    String[] terminals = {"(", ")", "a", "+", "$"};

    public LL1_Parser(String in) {
        this.input = in;
    }

    private void pushRule(String rule) {
        for (int i = rule.length() - 1; i >= 0; i--) {
            String str = String.valueOf(rule.charAt(i));
            push(str);
        }
    }

    public void algorithm() {
        push("$");
        push("S");
        String token = read();
        String top;

        do {
            top = pop();

            if (isNonTerminal(top)) {
                String rule = getRule(top, token);
                pushRule(rule);
            } else if (isTerminal(top)) {
                if (!top.equals(token)) {
                    error("Token mismatch. Expected: " + top + ", Found: " + token);
                } else {
                    System.out.println("Matched: " + token);
                    token = read();
                }
            } else {
                error("Unexpected symbol at top of stack: " + top);
            }

            if (top.equals("$") && token.equals("$")) {
                System.out.println("Input is Accepted by LL1");
                return;
            }

        } while (true);
    }

    private boolean isTerminal(String s) {
        for (String t : terminals) {
            if (s.equals(t)) return true;
        }
        return false;
    }

    private boolean isNonTerminal(String s) {
        for (String nt : nonTers) {
            if (s.equals(nt)) return true;
        }
        return false;
    }

    private String read() {
        indexOfInput++;
        if (indexOfInput < input.length()) {
            return String.valueOf(input.charAt(indexOfInput));
        }
        return "$";
    }

    private void push(String s) {
        strack.push(s);
    }

    private String pop() {
        return strack.pop();
    }

    private void error(String message) {
        System.out.println(message);
        throw new RuntimeException(message);
    }

    public String getRule(String non, String term) {
        int row = getnonTermIndex(non);
        int col = getTermIndex(term);
        String rule = table[row][col];
        if (rule == null) {
            error("No rule for Non-Terminal: " + non + ", Terminal: " + term);
        }
        return rule;
    }

    private int getnonTermIndex(String non) {
        for (int i = 0; i < nonTers.length; i++) {
            if (non.equals(nonTers[i])) return i;
        }
        error(non + " is not a Non-Terminal");
        return -1;
    }

    private int getTermIndex(String term) {
        for (int i = 0; i < terminals.length; i++) {
            if (term.equals(terminals[i])) return i;
        }
        error(term + " is not a Terminal");
        return -1;
    }

    public static void main(String[] args) {
        LL1_Parser parser = new LL1_Parser("(a+a)$");
        parser.algorithm();
    }
}
